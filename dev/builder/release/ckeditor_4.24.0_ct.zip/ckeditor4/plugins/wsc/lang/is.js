﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'is', {
	btnIgnore: 'Hunsa',
	btnIgnoreAll: 'Hunsa allt',
	btnReplace: 'Skipta',
	btnReplaceAll: 'Skipta öllu',
	btnUndo: 'Til baka',
	changeTo: 'Tillaga',
	errorLoading: 'Error loading application service host: %s.',
	ieSpellDownload: 'Villuleit ekki sett upp.<br>Viltu setja hana upp?',
	manyChanges: 'Villuleit lokið: %1 orðum breytt',
	noChanges: 'Villuleit lokið: Engu orði breytt',
	noMispell: 'Villuleit lokið: Engin villa fannst',
	noSuggestions: '- engar tillögur -',
	notAvailable: 'Sorry, but service is unavailable now.',
	notInDic: 'Ekki í orðabókinni',
	oneChange: 'Villuleit lokið: Einu orði breytt',
	progress: 'Villuleit í gangi...',
	title: 'Spell Checker',
	toolbar: 'Villuleit'
});

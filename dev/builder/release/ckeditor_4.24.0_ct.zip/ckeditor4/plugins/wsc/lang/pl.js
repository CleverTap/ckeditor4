﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'pl', {
	btnIgnore: 'Ignoruj',
	btnIgnoreAll: 'Ignoruj wszystkie',
	btnReplace: 'Zmień',
	btnReplaceAll: 'Zmień wszystkie',
	btnUndo: 'Cofnij',
	changeTo: 'Zmień na',
	errorLoading: 'Błąd wczytywania hosta aplikacji usługi: %s.',
	ieSpellDownload: 'Słownik nie jest zainstalowany. Czy chcesz go pobrać?',
	manyChanges: 'Sprawdzanie zakończone: zmieniono %l słów',
	noChanges: 'Sprawdzanie zakończone: nie zmieniono żadnego słowa',
	noMispell: 'Sprawdzanie zakończone: nie znaleziono błędów',
	noSuggestions: '- Brak sugestii -',
	notAvailable: 'Przepraszamy, ale usługa jest obecnie niedostępna.',
	notInDic: 'Słowa nie ma w słowniku',
	oneChange: 'Sprawdzanie zakończone: zmieniono jedno słowo',
	progress: 'Trwa sprawdzanie...',
	title: 'Sprawdź pisownię',
	toolbar: 'Sprawdź pisownię'
});

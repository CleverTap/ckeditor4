﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'ku', {
	btnIgnore: 'پشتگوێ کردن',
	btnIgnoreAll: 'پشتگوێکردنی ههمووی',
	btnReplace: 'لهبریدانن',
	btnReplaceAll: 'لهبریدانانی ههمووی',
	btnUndo: 'پووچکردنهوه',
	changeTo: 'گۆڕینی بۆ',
	errorLoading: 'ههڵه لههێنانی داخوازینامهی خانهخۆێی ڕاژه: %s.',
	ieSpellDownload: 'پشکنینی ڕێنووس دانهمزراوه. دهتهوێت ئێستا دایبگریت?',
	manyChanges: 'پشکنینی ڕێنووس کۆتای هات: لهسهدا %1 ی وشهکان گۆڕدرا',
	noChanges: 'پشکنینی ڕێنووس کۆتای هات: هیچ وشهیهك نۆگۆڕدرا',
	noMispell: 'پشکنینی ڕێنووس کۆتای هات: هیچ ههڵهیهکی ڕێنووس نهدۆزراوه',
	noSuggestions: '- هیچ پێشنیارێك -',
	notAvailable: 'ببووره، لهمکاتهدا ڕاژهکه لهبهردهستا نیه.',
	notInDic: 'لهفهرههنگ دانیه',
	oneChange: 'پشکنینی ڕێنووس کۆتای هات: یهك وشه گۆڕدرا',
	progress: 'پشکنینی ڕێنووس لهبهردهوامبوون دایه...',
	title: 'پشکنینی ڕێنووس',
	toolbar: 'پشکنینی ڕێنووس'
});

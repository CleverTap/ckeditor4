﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'hr', {
	btnIgnore: 'Zanemari',
	btnIgnoreAll: 'Zanemari sve',
	btnReplace: 'Zamijeni',
	btnReplaceAll: 'Zamijeni sve',
	btnUndo: 'Vrati',
	changeTo: 'Promijeni u',
	errorLoading: 'Greška učitavanja aplikacije: %s.',
	ieSpellDownload: 'Provjera pravopisa nije instalirana. Želite li skinuti provjeru pravopisa?',
	manyChanges: 'Provjera završena: Promijenjeno %1 riječi',
	noChanges: 'Provjera završena: Nije napravljena promjena',
	noMispell: 'Provjera završena: Nema grešaka',
	noSuggestions: '-Nema preporuke-',
	notAvailable: 'Žao nam je, ali usluga trenutno nije dostupna.',
	notInDic: 'Nije u rječniku',
	oneChange: 'Provjera završena: Jedna riječ promjenjena',
	progress: 'Provjera u tijeku...',
	title: 'Provjera pravopisa',
	toolbar: 'Provjeri pravopis'
});
